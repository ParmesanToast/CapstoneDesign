<template>

<router-view/>

</template>

<script>
export default {
  
  components: {

  },
  // el: 'app',
  // src:"https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.min.js",
}



</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 50px;
}
</style>
